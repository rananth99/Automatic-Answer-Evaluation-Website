import React from 'react';
import {BrowserRouter as Router} from 'react-router-dom';
import Route from 'react-router-dom/Route'
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import Test from './components/Test';
import Evaluate from './components/Evaluate';
import Answer from './components/Answer';
import Result from './components/Result';
import Add from './components/Add';


function App() {
  return (
    <Router>
      <div className="App">
        <Route exact path="/" component={Login} />
        <Route exact path="/Dashboard" component={Dashboard} />
        <Route exact path="/Test" component={Test} />
        <Route exact path="/Evaluate" component={Evaluate} />
        <Route exact path="/Answer" component={Answer} />
        <Route exact path="/Result" component={Result} />
        <Route exact path="/Add" component={Add} />
      </div>
    </Router>
  );
}

export default App;
