import React, { Component } from 'react'

export class Login extends Component {
    render() {
        return (
            <div>
        <title>Login Page</title>
        <div className="modal-dialog text-center">
          <div className="col-sm-8 main-section">
            <div className="modal-content">
              <div className="col-12 user-img">
                <img src="styles/img/face.png" />
              </div>
              <form className="col-12" action="dashboard">
                <div className="form-group">
                  <input type="text" className="form-control" placeholder="Enter Username" />
                </div>
                <div className="form-group">
                  <input type="password" className="form-control" placeholder="Enter Password" />
                </div>
                <button type="submit" className="btn"><i className="fas fa-sign-in-alt" />Login</button>
              </form>
              <div className="col-12 forgot">
                <a href="#">Forgot Password</a>
              </div>
            </div>
          </div>
        </div>
      </div>
        )
    }
}

export default Login