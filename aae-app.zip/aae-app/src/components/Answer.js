import React, { Component } from 'react'

export class Answer extends Component {
    render() {
        return (
            <div>
        <div className="wrapper">
          <div className="sidebar">
            <div className="user-img">
              <img src="styles/img/face.png" />
            </div>
            <div className="content">
              <h4>Faculty Name</h4>
              <h4>Subject Code</h4>
            </div>
            <ul>
              <li><a href="dashboard.html"><i className="fas fa-home" />HOME</a></li>
              <li><a href="test.html"><i className="fas fa-clipboard" />TEST</a></li>
              <li><a href="#"><i className="fas fa-check-circle" />EVALUATE</a></li>
              <li><a href="result.html"><i className="fas fa-poll" />RESULT</a></li>
              <li><a href="login.html"><i className="fas fa-sign-out-alt" />LOGOUT</a></li>
            </ul>
          </div>
        </div>
        <div align="center">
          <h1>Evaluate Webpage</h1>
        </div>
        <form action="eval.php">
          <div className="QA">
            <div className="form-qno">
              <label className="label-qno">Question No :</label>
              <input type="text" id="question_no" name="qno" className="form-qno" />
              <label className="label-ques">Question :</label>
              <input type="text" id="question" name="question" className="from-ques" /><br />
            </div>
            <div className="form-ans">
              <label className="label-ans">Answer :</label>
              <input type="text" id="answer" name="answer" className="form-ans" /><br />
            </div>
          </div>
          <div className="add_btn">
            <button type="submit" className="btn"><i className="far fa-check-circle" />EVALUATE</button>
          </div>
        </form>
        <form action="evaluate.html">
          <button className="exit_btn">BACK</button>
        </form>
      </div>
        )
    }
}

export default Answer