import React, { Component } from 'react'

export class Result extends Component {
    render() {
        return (
        	<div>
        		<div className="wrapper">
          <div className="sidebar">
            <div className="user-img">
              <img src="styles/img/face.png" />
            </div>
            <div className="content">
              <h4>Faculty Name</h4>
              <h4>Subject Code</h4>
            </div>
            <ul>
              <li><a href="dashboard"><i className="fas fa-home" />HOME</a></li>
              <li><a href="test"><i className="fas fa-clipboard" />TEST</a></li>
              <li><a href="evaluate"><i className="fas fa-check-circle" />EVALUATE</a></li>
              <li><a href="#"><i className="fas fa-poll" />RESULT</a></li>
              <li><a href="/"><i className="fas fa-sign-out-alt" />LOGOUT</a></li>
            </ul>
          </div>
        </div>
        <form action="dashboard">
          <button className="exit_btn">BACK</button>
        </form>
        	</div>
        )
    }
}

export default Result