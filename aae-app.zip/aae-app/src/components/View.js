import React, { Component } from 'react'

export class View extends Component {
    render() {
        return (
            <div>
        <div className="wrapper">
          <div className="sidebar">
            <div className="user-img">
              <img src="styles/img/face.png" />
            </div>
            <div className="content">
              <h4>Faculty Name</h4>
              <h4>Subject Code</h4>
            </div>
            <ul>
              <li><a href="dashboard.html"><i className="fas fa-home" />HOME</a></li>
              <li><a href="test.html"><i className="fas fa-clipboard" />TEST</a></li>
              <li><a href="evaluate.html"><i className="fas fa-check-circle" />EVALUATE</a></li>
              <li><a href="result.html"><i className="fas fa-poll" />RESULT</a></li>
              <li><a href="login.html"><i className="fas fa-sign-out-alt" />LOGOUT</a></li>
            </ul>
          </div>
        </div>
        <div align="center">
          <h1>View Webpage</h1>
        </div>
        <div className="table">
          <table>
            <tbody><tr>
                <th>Question No</th>
                <th>Question</th>
                <th>Answer</th>
              </tr>
              <tr>
                <td>1</td>
                <td>What is HTML?</td>
                <td>Hyper Text Markup Language</td>
              </tr>
              <tr>
                <td>2</td>
                <td>What is CSS?</td>
                <td>Cascading Style Sheet</td>
              </tr>
              <tr>
                <td>3</td>
                <td>Name an AJAX Pattern</td>
                <td>MultiStage Download , Predictive Fetch</td>
              </tr>
            </tbody></table>
        </div>
        <form action="test.html">
          <button className="exit_btn">BACK</button>
        </form>
      </div>
        )
    }
}

export default View