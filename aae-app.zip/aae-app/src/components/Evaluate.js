import React, { Component } from 'react'

export class Evaluate extends Component {
    render() {
        return (
            <div>
        <div className="wrapper">
          <div className="sidebar">
            <div className="user-img">
              <img src="styles/img/face.png" />
            </div>
            <div className="content">
              <h4>Faculty Name</h4>
              <h4>Subject Code</h4>
            </div>
            <ul>
              <li><a href="dashboard"><i className="fas fa-home" />HOME</a></li>
              <li><a href="test"><i className="fas fa-clipboard" />TEST</a></li>
              <li><a href="#"><i className="fas fa-check-circle" />EVALUATE</a></li>
              <li><a href="result"><i className="fas fa-poll" />RESULT</a></li>
              <li><a href="/"><i className="fas fa-sign-out-alt" />LOGOUT</a></li>
            </ul>
          </div>
        </div>
        <div className="table">
          <table>
            <tbody><tr>
                <th>Student Name</th>
                <th>SRN</th>
                <th>Section</th>
                <th>Answer</th>
                <th>Marks</th>
              </tr>
              <tr>
                <td>Ananth</td>
                <td>00286</td>
                <td>G</td>
                <td><a href="view-answer.html">ANSWER</a></td>
                <td>marks will be updated after evaluation</td>
              </tr>
              <tr>
                <td>Vishwas</td>
                <td>01321</td>
                <td>C</td>
                <td>answer link will be provided</td>
                <td>marks will be updated after evaluation</td>
              </tr>
              <tr>
                <td>Achintya</td>
                <td>00151</td>
                <td>F</td>
                <td>answer link will be provided</td>
                <td>marks will be updated after evaluation</td>
              </tr>			
            </tbody></table>
        </div>
        <form action="dashboard">
          <button className="exit_btn">BACK</button>
        </form>
      </div>
        )
    }
}

export default Evaluate