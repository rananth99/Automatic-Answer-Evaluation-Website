import React, { Component } from 'react'

export class Dashboard extends Component {
    render() {
        return (
            <div>
        <div className="wrapper">
          <div className="sidebar">
            <div className="user-img">
              <img src="styles/img/face.png" />
            </div>
            <div className="content">
              <h4>Faculty Name</h4>
              <h4>Subject Code</h4>
            </div>
            <ul>
              <li><a href="#"><i className="fas fa-home" />HOME</a></li>
              <li><a href="test"><i className="fas fa-clipboard" />TEST</a></li>
              <li><a href="evaluate"><i className="fas fa-check-circle" />EVALUATE</a></li>
              <li><a href="result"><i className="fas fa-poll" />RESULT</a></li>
              <li><a href="/"><i className="fas fa-sign-out-alt" />LOGOUT</a></li>
            </ul>
          </div>
        </div>
        <div className="main">
          <div className="grid">
            <a href="test" className="dashboard_clipboard">
              <img src="styles/img/test-2.png" width={150} height={150} alt="test" />
              <span>Test</span>
            </a>
            <a href="evaluate" className="dashboard_eval">
              <img src="styles/img/eval-2.png" width={150} height={150} alt="evaluate" />
              <span>Evaluate</span>
            </a>
            <a href="result" className="dashboard_result">
              <img src="styles/img/result-2.png" width={150} height={150} alt="result" />
              <span>Result</span>
            </a>
          </div>
        </div>
      </div>
        )
    }
}

export default Dashboard